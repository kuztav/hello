package library.dao;



import library.pojo.KeepItem;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import library.util.JDBCUtils;


/*
 * 管理员数据访问类
 */
public class AdminDao {

	public ArrayList<KeepItem> queryAllData() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<KeepItem> list = new ArrayList<KeepItem>();
		try {
			// 获得数据的连接
			conn = JDBCUtils.getConnection();
			// 获得Statement对象
			stmt = conn.createStatement();
			// 发送SQL语句
			String sql = "SELECT * FROM keep";
			rs = stmt.executeQuery(sql);
			// 处理结果集
			while (rs.next()) {
                KeepItem keepItem = new KeepItem();
				keepItem.setId(rs.getString("id"));
				keepItem.setKeepname(rs.getString("keepname"));
				keepItem.setStyle(rs.getString("style"));
				keepItem.setPrice(rs.getDouble("price"));
				list.add(keepItem);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.release(rs, stmt, conn);
		}
		return null;
	}
	//添加数据
	public void addKeepItem(KeepItem keepItem) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// 获得数据的连接
			conn = JDBCUtils.getConnection();
			// 获得Statement对象
			stmt = conn.createStatement();
			// 发送SQL语句
			String sql = "INSERT INTO keep(id,keepname,style,price)"
					+ "VALUES(" + keepItem.getId() + ",'" + keepItem.getKeepname()
					+ "','" + keepItem.getStyle() + "','" + keepItem.getPrice()+ "')";
			int num = stmt.executeUpdate(sql);
			if (num == 1) {
				System.out.println("insert success！");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.release(rs, stmt, conn);
		}	
	}
	//删除数据
	public void delKeepItem(String delId) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// 获得数据的连接
			conn = JDBCUtils.getConnection();
			// 获得Statement对象
			stmt = conn.createStatement();
			// 发送SQL语句
			String sql = "DELETE FROM keep WHERE id=" + delId;
			int num = stmt.executeUpdate(sql);
			if (num > 0) {
             System.out.println("del success！");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.release(rs, stmt, conn);
		}
	}
}
