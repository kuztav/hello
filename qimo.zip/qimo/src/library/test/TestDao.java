package library.test;



import library.pojo.KeepItem;
import library.dao.AdminDao;

import java.util.ArrayList;

/**
 * 测试JDBC
 */
public class TestDao {
	public static void main(String[] args) {
		AdminDao ad = new AdminDao();
		System.out.println(ad.queryAllData());
		ArrayList<KeepItem> list = new ArrayList<KeepItem>();
		list = ad.queryAllData();
		for (KeepItem keepItem : list) {
			System.out.println(keepItem.getId());
			System.out.println(keepItem.getKeepname());
			System.out.println(keepItem.getStyle());
			System.out.println(keepItem.getPrice());
		}
	}

}
