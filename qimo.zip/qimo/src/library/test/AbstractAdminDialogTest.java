package library.test;



import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import library.frame.AbstractAdminDialog;

/*
 * 管理界面测试类
 */
@SuppressWarnings("serial")
public class AbstractAdminDialogTest extends AbstractAdminDialog {
	//定义构造函数初始化数据
	public AbstractAdminDialogTest() {
		super();
		queryKeepItem();//测试数据
	}	
	//加入测试table数据
	@Override
	public void queryKeepItem() {
		String[] thead = new String[]{"pay id","pay name ","pay style","pay amount"};
		String[][] tbody = new String[][]{
				{"1","吃饭支出","交通银行","998"},
				{"2","吃饭支出","交通银行","998"},
				{"3","吃饭支出","交通银行","998"},
				{"4","吃饭支出","交通银行","998"}
				};
		TableModel data = new DefaultTableModel(tbody,thead);
		table.setModel(data);
	}
	@Override
	public void addKeepItem() {
	}
	@Override
	public void updateKeepItem() {
	}
	@Override
	public void delKeepItem() {
	}
    //定义主函数运行程序
	public static void main(String[] args) {
		//创建界面并显示
		new AbstractAdminDialogTest().setVisible(true);
	}
}
