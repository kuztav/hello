package library.frame;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import library.util.GUITools;

/**
 * 管理窗口类
 */
@SuppressWarnings("serial")
public abstract class AbstractAdminDialog extends JDialog{
	//定义界面使用到的组件作为成员变量
	private JLabel tableLabel = new JLabel("pay list");
	private JScrollPane tablePane = new JScrollPane();
	protected JTable table = new JTable();
	private JLabel idLabel = new JLabel("pay id");
	private JLabel keepnameLabel = new JLabel("pay name");
	private JLabel styleLabel = new JLabel("pay style");
	private JLabel priceLabel = new JLabel("pay amount");
	//添加功能组件
	protected JTextField addIdText = new JTextField(6);
	protected JTextField addKeepNameText = new JTextField(6);//添加名称文本框
	protected JTextField addStyleText = new JTextField(6);//添加单价文本框
	protected JTextField addPriceText = new JTextField(6);//添加计价单位文本框
	private JButton addBtn = new JButton("add pay");//添加按钮
	//修改功能组件
	protected JTextField updateIdText = new JTextField(6);//修改编号文本框
	protected JTextField updateKeepNameText = new JTextField(6);//修改名称文本框
	protected JTextField updateStyleText = new JTextField(6);//修改计价单位文本框
	protected JTextField updatePriceText = new JTextField(6);//修改单价文本框
	private JButton updateBtn = new JButton("update pay");//修改按钮
	//删除功能组件
	protected JTextField delIdText = new JTextField(6);//添加编号文本
	private JButton delBtn = new JButton("delete pay");//删除按钮
	//构造方法
	public AbstractAdminDialog() {
		this(null,true);
	}
	public AbstractAdminDialog(Frame owner, boolean modal) {
		super(owner, modal);
		this.init();// 初始化操作
		this.addComponent();// 添加组件
		this.addListener();// 添加监听器
	}
	// 初始化操作
	private void init() {
		this.setTitle("pay manage!");// 标题
		this.setSize(600, 400);// 窗体大小与位置
		GUITools.center(this);//设置窗口在屏幕上的位置
		this.setResizable(false);// 窗体大小固定
	}	
	// 添加组件
	private void addComponent() {		
		//取消布局
		this.setLayout(null);		
		//表格标题
		tableLabel.setBounds(265, 20, 70, 25);
		this.add(tableLabel);		
		//表格
		table.getTableHeader().setReorderingAllowed(false);	//列不能移动
		table.getTableHeader().setResizingAllowed(false); 	//不可拉动表格
		table.setEnabled(false);							//不可更改数据
		tablePane.setBounds(50, 50, 500, 200);				
		tablePane.setViewportView(table);					//视口装入表格
		this.add(tablePane);		
		//字段标题
		idLabel.setBounds(50, 250, 70, 25);
		keepnameLabel.setBounds(150, 250, 70, 25);
		priceLabel.setBounds(350, 250, 70, 25);
		styleLabel.setBounds(250, 250, 70, 25);
		this.add(idLabel);
		this.add(keepnameLabel);
		this.add(styleLabel);
		this.add(priceLabel);
		//增加组件
		addIdText.setBounds(50, 280, 80, 25);
		addKeepNameText.setBounds(150, 280, 80, 25);
		addPriceText.setBounds(350, 280, 80, 25);
		addStyleText.setBounds(250, 280, 80, 25);
		this.add(addIdText);
		this.add(addKeepNameText);
		this.add(addStyleText);
		this.add(addPriceText);
		addBtn.setBounds(460, 280, 90, 25);
		this.add(addBtn);		
		//修改组件
		updateIdText.setBounds(50, 310, 80, 25);
		updateKeepNameText.setBounds(150, 310, 80, 25);
		updatePriceText.setBounds(350, 310, 80, 25);
		updateStyleText.setBounds(250, 310, 80, 25);
		this.add(updateIdText);
		this.add(updateKeepNameText);
		this.add(updateStyleText);
		this.add(updatePriceText);
		updateBtn.setBounds(460, 310, 90, 25);
		this.add(updateBtn);		
		//删除组件
		delIdText.setBounds(50, 340, 80, 25);
		this.add(delIdText);
		delBtn.setBounds(460, 340, 90, 25);
		this.add(delBtn);
	}	
	// 添加监听器
	private void addListener() {		
		//添加按钮监听
		addBtn.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				//调用添加方法
				addKeepItem();
			}
		});
		//修改按钮监听
		updateBtn.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				//调用修改方法
				updateKeepItem();
			}
		});
		//删除按钮监听
		delBtn.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				//调用删除方法
				delKeepItem();
			}
		});
	}	
	//查询方法
	public abstract void queryKeepItem();
	//添加方法
	public abstract void addKeepItem();
	//修改方法
	public abstract void updateKeepItem();
	//删除方法
	public abstract void delKeepItem();
}
