package library.controller;



import library.pojo.KeepItem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import library.frame.AbstractAdminDialog;
import library.service.AdminService;
import java.util.ArrayList;

/**
 * 管理员界面操作类
 */
@SuppressWarnings("serial")
public class AdminDialogController extends AbstractAdminDialog {
	//定义服务类，提供完整功能服务
	private AdminService adminService = new AdminService();
	//构造方法
	public AdminDialogController() {
		super();
	}
	public AdminDialogController(Frame owner, boolean modal) {
		super(owner, modal);
		//创建对象时展示数据
		queryKeepItem();
	}



	//查询方法
	@Override
	public void queryKeepItem() {
		//定义表格头
		String[] thead = {"pay id","pay name","pay style ","pay amount"};
		
		//调用adminService的查询服务
		ArrayList<KeepItem> dataList = adminService.queryKeepItem();
		//调用list2Array方法，将查询到的集合转为数组，方便为JTable赋值
		String[][] tbody = list2Array(dataList);
		//将查询到的结果为table赋值
		TableModel dataModel = new DefaultTableModel(tbody, thead);
		table.setModel(dataModel);
	}
	//集合数据转为二维数组方法
	public String[][] list2Array(ArrayList<KeepItem> list){
		//根据FruitItem的model与集合数据定义JTable的数据二维数组
		String[][] tbody = new String[list.size()][4];	
		for (int i = 0; i < list.size(); i++) {
			KeepItem fruitItem = list.get(i);
			tbody[i][0] = fruitItem.getId();
			tbody[i][1] = fruitItem.getKeepname();
			tbody[i][2] = fruitItem.getStyle();
			tbody[i][3] = fruitItem.getPrice()+"";
		}		
		return tbody;
	}
	//添加方法
	@Override
	public void addKeepItem() {
		//获取数据
		String addId = addIdText.getText();
		String addKeepName = addKeepNameText.getText();
		String addStyle = addStyleText.getText();
		Double addPrice = Double.valueOf(addPriceText.getText());
		//调用adminService的添加服务
		boolean addSuccess = adminService.addKeepItem(addId, addKeepName,
				addStyle, addPrice);
		//如果添加成功
		if(addSuccess) {
			//添加后刷新表格
			queryKeepItem();
		}else {
			//没有添加成功弹窗错误提示
			JOptionPane.showMessageDialog(this, "pay id  can't unique,please check data!");
		}
	}
	//修改方法
	@Override
	public void updateKeepItem() {
		//获取数据
		String updateId = updateIdText.getText();
		String updateKeepName = updateKeepNameText.getText();
		String updateStyle = updateStyleText.getText();
		Double updatePrice = Double.valueOf(updatePriceText.getText());
		//调用adminService的修改服务
		boolean updateSuccess = adminService.updateKeepItem(updateId,
				updateKeepName, updateStyle, updatePrice);
		//如果修改成功
		if(updateSuccess) {
			//修改后刷新表格
			queryKeepItem();
		}else {
			//没有修改成功弹窗错误提示
			JOptionPane.showMessageDialog(this, "Spending Without this number,please check data!");
		}
	}
	//删除方法
	@Override
	public void delKeepItem() {
		//获取数据
		String delId = delIdText.getText();
		//调用adminService的删除服务
		boolean delSuccess = adminService.delKeepItem(delId);
		//如果删除成功
		if(delSuccess) {
			//删除后刷新表格
			queryKeepItem();
		}else {
			//没有删除成功弹窗错误提示
			JOptionPane.showMessageDialog(this, "Spending Without this number,please check data!");
		}
	}	
}