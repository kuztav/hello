package library.pojo;

public class KeepItem {

	private String id;
	private String keepname;
	private String style;
	private double price;


	public KeepItem(String id, String keepname, String style, Double price) {
		super();
		this.id = id;
		this.keepname = keepname;
		this.style = style;
		this.price = price;
	}

	public KeepItem() {

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getKeepname() {
		return keepname;
	}

	public void setKeepname(String keepname) {
		this.keepname = keepname;
	}

	public String getStyle() {
		return style;
	}

	public void setStyle(String style) {
		this.style = style;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
}